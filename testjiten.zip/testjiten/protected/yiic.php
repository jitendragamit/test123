<?php

// change the following paths if necessary
$yiic=dirname(__FILE__).'/../../yii-1.1.17.467ff50/framework/yiic.php';
$config=dirname(__FILE__).'/config/console.php';

require_once($yiic);
