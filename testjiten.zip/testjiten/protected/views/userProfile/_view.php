<?php
/* @var $this UserProfileController */
/* @var $data UserProfile */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('id')); ?>:</b>
	<?php  echo CHtml::link(CHtml::encode($data->id), array('view', 'id'=>$data->id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('username')); ?>:</b>
	<?php echo CHtml::encode($data->username); ?>
	<br />

	

	<b><?php // echo CHtml::encode($data->getAttributeLabel('profile_pic')); ?></b>
	<?php //echo CHtml::encode($data->profile_pic); ?>
	
	<img src="<?php echo Yii::app()->params['upload_path_url'];?><?php echo CHtml::encode($data->profile_pic); ?>">
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('phone')); ?>:</b>
	<?php echo CHtml::encode($data->phone); ?>
	<br />

</div>