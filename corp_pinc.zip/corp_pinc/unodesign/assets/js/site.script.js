$(document).ready(function(){
	
  
	/*Homepage Banner Effect*/
	$(".home-left").hover(function () {
		$("#home-banner").addClass("home-retail-bg");
		$('#retail').show();
	  });
	
	$(".home-right").mouseenter(
	  function () {	
		$("#home-banner").removeClass("home-retail-bg");
		$('#retail').hide();		  
	  });

	$(".home-right").hover(function () {
		$("#home-banner").addClass("home-corp-bg");
		$('#corporate').show();
	  });
	
	$(".home-left").mouseenter(
	  function () {	
		$("#home-banner").removeClass("home-corp-bg");
		$('#corporate').hide();		  
	  });
    
	
});