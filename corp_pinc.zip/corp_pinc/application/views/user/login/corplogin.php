<!doctype html>
<html>
<head>
<!--Dont Edit/Remove this part (Start) // This is for responsive-->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7; IE=EmulateIE9">
<meta name="HandheldFriendly" content="true">
<meta name="viewport" content="width=device-width; initial-scale=0.666667; maximum-scale=0.666667; user-scalable=0">
<meta name="viewport" content="width=device-width">
<!--Dont Remove this part (End)-->

<title>Login Page</title>

<!--Include Css -->
<link rel="stylesheet" type="text/css" href="./unodesign/assets/css/backend-styles.css">

<!--Include JS -->
<script src="./unodesign/assets/js/jquery-1.9.1.min.js"></script>
<script src="./unodesign/assets/js/bootstrap.min.js"></script>

</head>

<body>
	<!--Header Section-->
	<div class="maskbox"></div>
	<div class="back-img "></div>
	<header>
		<div class="topbar">
		    <div class="container">
			  <div class="logo"><img src="./unodesign/assets/images/logo.png"></div>
				<div class="soc-icon">
					<ul>
						<li><a href="#"><img src="./unodesign/assets/images/icon-call.png"></a></li>
						<li><a href="#"><img src="./unodesign/assets/images/icon-chat.png"></a></li>
						<li class="soc-bar"></li>
						<li><a href="#"><img src="./unodesign/assets/images/icon-linkedin.png"></a></li>
						<li><a href="#"><img src="./unodesign/assets/images/icon-twitter.png"></a></li>
						<li><a href="#"><img src="./unodesign/assets/images/icon-instagram.png"></a></li>
						<li><a href="#"><img src="./unodesign/assets/images/icon-facebook.png"></a></li>
					</ul>		
				</div>
			</div>					
	    </div>
	</header>   
	
	<section>
		 <div class="container">
												
			<div class="log-box animated slideInUp">						
				<h2>Get started</h2>
				<div class="clearfix"></div>
				
				<form name="frm_corp_login" action="./corplogin" method="post">
				<div class="lb-form-con">
				
				<div class="user">
					<input type="text" class="usertb" placeholder="User ID" name="username" id="username">
				</div>
				
				<div class="pwd">
					<input type="password" class="pwdtb" placeholder="Password" name="password" id="password">
				</div>
				
				<input type="submit" class="button" value="Submit">
				
				<div class="clearfix"></div>
					<?php if (isset($error)) : ?>
					<div class="alert alert-danger">
						  <?php echo $error; ?>
					</div>
					<?php endif; ?>
				<div class="clearfix"></div>
				
				</div>
				</form>
				<div class="animated flipInY features-con">
					<ul class="features">
						<li><img src="./unodesign/assets/images/save-time.png"></li>
						<li><img src="./unodesign/assets/images/upload-documents.png"></li>
						<li><img src="./unodesign/assets/images/manage-policies.png"></li>
					</ul>
				</div>

			</div>
										
		 </div>			
	</section> 
	
	

	
</body>
</html>
