<!doctype html>
<html>
<head>
<!--Dont Edit/Remove this part (Start) // This is for responsive-->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7; IE=EmulateIE9">
<meta name="HandheldFriendly" content="true">
<meta name="viewport" content="width=device-width; initial-scale=0.666667; maximum-scale=0.666667; user-scalable=0">
<meta name="viewport" content="width=device-width">
<!--Dont Remove this part (End)-->

<title>Login Page</title>

<!--Include Css -->
<link rel="stylesheet" type="text/css" href="./unodesign/assets/css/backend-styles.css">

<!--Include JS -->
<script src="./unodesign/assets/js/jquery-1.9.1.min.js"></script>
<script src="./unodesign/assets/js/site.script.js"></script>
<script src="./unodesign/assets/js/bootstrap.min.js"></script>

</head>

<body>
	<!--Header Section-->
	<div id="home-banner" class="home-bg"></div>
	<header>
		<div class="topbar">
		    <div class="container">
			  <div class="logo"><img src="./unodesign/assets/images/logo.png"></div>
				<div class="soc-icon">
					<ul>
						<li><a href="#"><img src="./unodesign/assets/images/icon-call.png"></a></li>
						<li><a href="#"><img src="./unodesign/assets/images/icon-chat.png"></a></li>
						<li class="soc-bar"></li>
						<li><a href="#"><img src="./unodesign/assets/images/icon-linkedin.png"></a></li>
						<li><a href="#"><img src="./unodesign/assets/images/icon-twitter.png"></a></li>
						<li><a href="#"><img src="./unodesign/assets/images/icon-instagram.png"></a></li>
						<li><a href="#"><img src="./unodesign/assets/images/icon-facebook.png"></a></li>
					</ul>		
				</div>
			</div>					
	    </div>
	</header>   
	
	<section>
	
		<div class="home-left">
			<div id="retail"  class="con-box animated fadeInUp">
				<ul class="conbox-icon">
					<li><img src="./unodesign/assets/images/car.png"></li>
					<li><img src="./unodesign/assets/images/two-wheeler.png"></li>
					<li><img src="./unodesign/assets/images/term-life.png"></li>				
				</ul>
				<h5><a href="#">Go with <br> Retail Customer</a></h5>
			</div>	
		</div>
		<div class="home-right">			
			<div id="corporate" class="con-box animated fadeInDown">
				<ul class="conbox-icon">
					<li><img src="./unodesign/assets/images/grp-medicl.png"></li>
					<li><img src="./unodesign/assets/images/grp-travel.png"></li>
					<li><img src="./unodesign/assets/images/shopkeep-rack.png"></li>				
				</ul>
				<h5><a href="./corplogin">Go with <br> Corporate Customer</a></h5>
			</div>	
		</div>
		
	</section> 
	
	

	
</body>
</html>
