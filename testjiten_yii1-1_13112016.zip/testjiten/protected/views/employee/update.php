<?php
/* @var $this EmployeeController */
/* @var $model TblEmployee */

$this->breadcrumbs=array(
	'Tbl Employees'=>array('index'),
	$model->name=>array('view','id'=>$model->id),
	'Update',
);

$this->menu=array(
	array('label'=>'List TblEmployee', 'url'=>array('index')),
	array('label'=>'Create TblEmployee', 'url'=>array('create')),
	array('label'=>'View TblEmployee', 'url'=>array('view', 'id'=>$model->id)),
	array('label'=>'Manage TblEmployee', 'url'=>array('admin')),
);
?>

<h1>Update TblEmployee <?php echo $model->id; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>