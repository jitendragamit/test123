<?php
/* @var $this EmployeeController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Tbl Employees',
);

$this->menu=array(
	array('label'=>'Create TblEmployee', 'url'=>array('create')),
	array('label'=>'Manage TblEmployee', 'url'=>array('admin')),
);
?>

<h1>Tbl Employees</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
