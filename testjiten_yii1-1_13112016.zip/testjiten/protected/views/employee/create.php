<?php
/* @var $this EmployeeController */
/* @var $model TblEmployee */

$this->breadcrumbs=array(
	'Tbl Employees'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List TblEmployee', 'url'=>array('index')),
	array('label'=>'Manage TblEmployee', 'url'=>array('admin')),
);
?>

<h1>Create TblEmployee</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>