<?php
/* @var $this EmployeeController */
/* @var $model TblEmployee */

$this->breadcrumbs=array(
	'Tbl Employees'=>array('index'),
	'Manage',
);

/*
$this->menu=array(
	array('label'=>'List TblEmployee', 'url'=>array('index')),
	array('label'=>'Create TblEmployee', 'url'=>array('create')),
);
*/


Yii::app()->clientScript->registerScript('search', "
$('.search-button').click(function(){
	$('.search-form').toggle();
	return false;
});
$('.search-form form').submit(function(){
	$('#tbl-employee-grid').yiiGridView('update', {
		data: $(this).serialize()
	});
	return false;
});
");
?>

<h1>Manage Tbl Employees</h1>




<div class="text-right margin-top10">
    <?php echo CHtml::link('<i class="fa fa-upload maroon"></i> Add Issue', array('Employee/create'), array('class' => 'black _blank')); ?>
</div>



<?php //echo CHtml::link('Advanced Search','#',array('class'=>'search-button')); ?>

<div class="search-form" style="display:none">
<?php $this->renderPartial('_search',array(
	'model'=>$model,
)); ?>
</div><!-- search-form -->

<?php $this->widget('zii.widgets.grid.CGridView', array(
	'id'=>'tbl-employee-grid',
	'dataProvider'=>$model->search(),
	'filter'=>$model,
	'columns'=>array(
		
		array(
            'header' => 'Sr.No.',
            'value' => '$this->grid->dataProvider->pagination->currentPage * $this->grid->dataProvider->pagination->pageSize + ($row+1)',
            'htmlOptions' => array(
                'style' => 'width:5%;'
            ),
        ),


		'name',
		'city',
		'phone',
		array(
			'class'=>'CButtonColumn',
		),
	),
)); ?>
